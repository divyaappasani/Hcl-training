package com.interfacethree;

public interface Polygon {

}
