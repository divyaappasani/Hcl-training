package com.interfacetwo;

public interface Fort {
	public  void distance();
}
