package com.interfacetwo;

public class Rajmachi implements Fort{

	@Override
	public void distance() {
		System.out.println("You are going to visit Rajmachi");
		System.out.println("The distance is 55 km");		
	}
	

}
