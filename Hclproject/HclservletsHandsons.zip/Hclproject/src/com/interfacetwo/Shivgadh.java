package com.interfacetwo;

public class Shivgadh implements Fort {

	@Override
	public void distance() {
		System.out.println("You are going to visit Shivgadh");
		System.out.println("The distance is 100 km");		
	}

}
