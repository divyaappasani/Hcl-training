package com.exampleinterface;

public interface Stall {
	void display();
}
