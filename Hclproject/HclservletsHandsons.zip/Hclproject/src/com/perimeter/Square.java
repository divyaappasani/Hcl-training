package com.perimeter;

public class Square extends ShapeTwo{
	float side;
	public Square() {
	}

	public Square(float side) {
		super();
		this.side = side;
	}


	public float getSide() {
		return side;
	}

	public void setSide(float side) {
		this.side = side;
	}

	@Override
	public double calculatePerimeter() {
		double p=4*side;
		return p;
	}
	

}
