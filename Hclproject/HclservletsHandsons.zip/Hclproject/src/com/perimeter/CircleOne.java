package com.perimeter;

public class CircleOne extends ShapeTwo {
	float radius;

	public CircleOne() {
	}

	public CircleOne(float radius) {
		super();
		this.radius = radius;
	}

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	@Override
	public double calculatePerimeter() {
		double p = 2 * (3.14) * radius;

		return p;
	}

}
