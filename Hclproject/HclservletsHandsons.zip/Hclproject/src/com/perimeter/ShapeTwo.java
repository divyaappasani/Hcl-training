package com.perimeter;

public abstract class ShapeTwo {

	public abstract double calculatePerimeter();
}
