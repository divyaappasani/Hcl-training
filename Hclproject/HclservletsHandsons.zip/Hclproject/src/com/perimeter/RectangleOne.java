package com.perimeter;

public class RectangleOne extends ShapeTwo {
float length,breadth;
public RectangleOne() {
}

public RectangleOne(float length, float breadth) {
	super();
	this.length = length;
	this.breadth = breadth;
}


public float getLength() {
	return length;
}

public void setLength(float length) {
	this.length = length;
}

public float getBreadth() {
	return breadth;
}

public void setBreadth(float breadth) {
	this.breadth = breadth;
}

@Override
public double calculatePerimeter() {
	double p=2*(length+breadth); 
	return p;
}

}
