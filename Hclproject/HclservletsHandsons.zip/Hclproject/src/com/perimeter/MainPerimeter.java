package com.perimeter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainPerimeter {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int ch;
		System.out.println("Enter the shape" + "\n" + "1.Circle" + "\n" + "2.Rectangle" + "\n" + "3.Triangle");
		ch = Integer.parseInt(br.readLine());
		if (ch == 1) {
			System.out.println("Enter the radius:");
			float radius = Float.parseFloat(br.readLine());
			CircleOne s1 = new CircleOne(radius);
			s1.calculatePerimeter();
		}
		else if(ch==2) {
			
		}
	}

}
