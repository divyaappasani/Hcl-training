package com.loggerexample;
import org.apache.log4j.Logger;

import java.io.*;
import java.sql.SQLException;
import java.util.*;



public class Programlog4jExample {
	/* Get actual class name to be printed on */
	   static Logger log = Logger.getLogger(Programlog4jExample.class.getName());
	   
	   public static void main(String[] args)throws IOException,SQLException
	    {
	      log.debug("It is a debug message");
	      log.info("It is an info message");
	    }

}
