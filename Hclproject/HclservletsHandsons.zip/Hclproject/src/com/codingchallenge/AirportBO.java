package com.codingchallenge;

public class AirportBO {
	public Airport createAirport(String data,Country[] countryList) {
		String	airportName;
		Country[] country;
		String details1[]=data.split(",");
		airportName=details1[0];
		for(c in countryList) {
		country[]=details1[countryList];
		}
		
		
		Airport a=new Airport(airportName, country);
	}
	public String findCountryName(Airport[] airportList, String airportname){
		
	}
	public Boolean findWhetherAirportsAreInSameCountry (Airport[] airportList, String airportname1, String airportname2) {
		if(airportname1.equals(airportname2)){
			return true;
		}
	}

}
