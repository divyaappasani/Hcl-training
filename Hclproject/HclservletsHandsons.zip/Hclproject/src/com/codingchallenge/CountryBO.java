package com.codingchallenge;

public class CountryBO {
	public Country createCountry(String data) {
		String details[]=data.split(",");
		String iataCountryCode,countryName;
		iataCountryCode=details[0];
		countryName=details[1];
		Country c=new Country(iataCountryCode, countryName);
		return c;
	}

}
