package com.strings.one;


public class MainTwo {

	public static void main(String[] args) {

		System.out.println("Enter Humpty's Sentence :");
		
		StringBuffer s=new StringBuffer("Hello");
		System.out.println(s);
		System.out.println("Dumpty Says,"+s.reverse());
	}

}
