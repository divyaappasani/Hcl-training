package com.collection.six;

public class SummaryLog {
	String dialledNumber, totalDuration;
}
