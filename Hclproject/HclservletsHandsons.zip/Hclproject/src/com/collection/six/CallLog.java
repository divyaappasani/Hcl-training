package com.collection.six;

public class CallLog {
	String dialledNumber, duration, dialledDate; 

}
