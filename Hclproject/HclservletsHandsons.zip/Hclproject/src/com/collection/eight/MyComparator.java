package com.collection.eight;

import java.util.Comparator;

public class MyComparator implements Comparator{
	public int compare(Object obj1,Object obj2)
	{
		CallLog e1=(CallLog)obj1;
		CallLog e2=(CallLog)obj2;
		String s1=e1.getName();
		String s2=e2.getName();
		return s2.compareTo(s1);
		}

}
