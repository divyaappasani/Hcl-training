package com.interfaceone;

import java.util.Scanner;

public class Service implements Car{
	Scanner sc = new Scanner(System.in);

	@Override
	public void sum() {
		System.out.println("Enter your car number");
		String s = sc.nextLine();
		String s1[]=s.split("");
		int res=Integer.parseInt(s1[0]+s1[1]+s1[2]+s1[3]);
		if(res%2==0) {
			System.out.println("You can come on Tuesday, Thursday or Saturday");
		}
		else
			System.out.println("You can come on Monday, Wednesday and Friday");
	}

	@Override
	public void years() {
		System.out.println("How many years old car do you have-");
		int n=sc.nextInt();
		if(n>5) {
			System.out.println("You are eligible for free washing");
		}else
			System.out.println("You are not eligible for free washing");
		
	}

	@Override
	public void brand() {
		System.out.println("Car Brand-");
		String s1=sc.nextLine();
		if(s1.equals("Maruthi")) {
			double d=(5000*5)/100;
			double discount=5000-d;
			System.out.println("Discount is"+discount);
		}
		else System.out.println("No Discount");
		
	}

}
