package com.interfaceone;

public interface Car {
	public void sum();
	public  void  years();
	public void  brand();
}
