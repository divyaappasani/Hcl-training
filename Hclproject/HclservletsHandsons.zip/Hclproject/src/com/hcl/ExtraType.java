package com.hcl;

public class ExtraType {
	String name; 
	long runs;
	public ExtraType() {
		
	}
	public ExtraType(String name, long runs) {
		super();
		this.name = name;
		this.runs = runs;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getRuns() {
		return runs;
	}
	public void setRuns(long runs) {
		this.runs = runs;
	}
	
	

}
