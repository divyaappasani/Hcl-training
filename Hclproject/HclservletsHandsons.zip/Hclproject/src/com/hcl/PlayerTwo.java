package com.hcl;

public class PlayerTwo {
	String name,country,skill;
	
	public PlayerTwo(String name, String country, String skill) {
		super();
		this.name = name;
		this.country = country;
		this.skill = skill;
	}

	
	

}
