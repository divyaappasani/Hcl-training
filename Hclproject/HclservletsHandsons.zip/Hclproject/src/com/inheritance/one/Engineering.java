package com.inheritance.one;

public class Engineering extends HLCollege {
	String building_name;
	int no_of_branches;
public Engineering() {
}
public Engineering(String registration_no, String name, String place, String trustee_names, int foundation_year,String building_name,
int no_of_branches) {
	super(registration_no, name, place, trustee_names, foundation_year);
	this.building_name=building_name;
	this.no_of_branches=no_of_branches;
}
public String getBuilding_name() {
	return building_name;
}
public void setBuilding_name(String building_name) {
	this.building_name = building_name;
}
public int getNo_of_branches() {
	return no_of_branches;
}
public void setNo_of_branches(int no_of_branches) {
	this.no_of_branches = no_of_branches;
}
public void showBranchDetails() {
	
}


}
