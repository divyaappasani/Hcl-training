package com.inheritance.one;

public class HLCollegeService {
	String place,registration_no,name,trustee_names,building_name;
	int foundation_year,no_of_branches;
	public HLCollegeService() {
	}
	
	public HLCollegeService(String place, String registration_no, String name, String trustee_names,
			int foundation_year, String building_name, int no_of_branches) {
		super();
		this.place = place;
		this.registration_no = registration_no;
		this.name = name;
		this.trustee_names = trustee_names;
		this.foundation_year = foundation_year;
		this.building_name = building_name;
		this.no_of_branches = no_of_branches;
	}

	public String getPlace() {
		return place;
	}
	public String getRegno(String place) {
		return "mh"+place.substring(0,2)+registration_no;
	}
	public void validateRegno(String regno, String
			place) 
	{
		
	}
	public String getCollegeName(){
		return name;
	}
	public String getTrustee_names() {
		return trustee_names;
	}
	
	public int getFoundation_year() {
		return foundation_year;
	}
	public String getBuilding_name() {
		return building_name;
	}
	public int getBranches() {
		return no_of_branches;
	}
	
	
}
