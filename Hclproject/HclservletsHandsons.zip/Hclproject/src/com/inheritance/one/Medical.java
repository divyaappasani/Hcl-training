package com.inheritance.one;

public class Medical extends HLCollege{

	String building_name;
	int no_of_branches;
	Boolean attached_hospital;
	public Medical() {
	}
	public Medical(String registration_no, String name, String place, String trustee_names,int foundation_year,String building_name, int no_of_branches, Boolean attached_hospital) {
		super(registration_no, name, place, trustee_names, foundation_year);
		this.building_name = building_name;
		this.no_of_branches = no_of_branches;
		this.attached_hospital = attached_hospital;
	}
	public String getBuilding_name() {
		return building_name;
	}
	public void setBuilding_name(String building_name) {
		this.building_name = building_name;
	}
	public int getNo_of_branches() {
		return no_of_branches;
	}
	public void setNo_of_branches(int no_of_branches) {
		this.no_of_branches = no_of_branches;
	}
	public Boolean getAttached_hospital() {
		return attached_hospital;
	}
	public void setAttached_hospital(Boolean attached_hospital) {
		this.attached_hospital = attached_hospital;
	}
	public void showBranchDetails() {
		
	}
	public void getInternshipInfo() {
		
	}
	
}
