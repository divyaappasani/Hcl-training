package com.ttt;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	try {
		args=null;
		args[0]="welcome";
		System.out.println(args[0]);

	}
	catch(Exception e) {
		System.out.println("exc");
	}
	catch(NullPointerException exception) {
		System.out.println("null");
	}

}
}