package com.bookmyshow.dao;

import java.util.List;

import com.bookmyshow.model.Seat_Selector;

public interface seat_selectorDao {

	void insert(Seat_Selector seat);
	//List<Seat_Selector> getSeatingSelection ();
}
